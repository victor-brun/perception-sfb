# perception-sfb
Studying the perceptions of local people on coastal management
